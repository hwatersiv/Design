export interface ISearchTabs {
  title: string;
  toggleVar: number;
}
export interface ISearchTabState {
  group: number;
  filter: number;
  logic: number;
  null: number;
}
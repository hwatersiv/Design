export interface IResponse {
  class?: string[];
  entities?: Array<any>;
  links?: Array<any>;
  properties?: Object;
  title?: string;
}